import { useState } from "react";
import { store, DEMO } from "../lib/api.js";

export default function Auth({ onDone }) {
  const [mode, setMode] = useState("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const submit = async () => {
    setErr("");
    setBusy(true);
    try {
      if (mode === "signup") await store.signUp({ name, email, password });
      else await store.signIn({ email, password });
      await onDone();
    } catch (e) {
      setErr(e.message || "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rise" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
      <div style={{ padding: "18px 4px 22px" }}>
        <p className="eyebrow">A naming journey for two</p>
        <h1 className="display" style={{ fontSize: 40, fontWeight: 600, margin: "8px 0 10px" }}>
          Find the name<br />you'll both love.
        </h1>
        <p className="muted" style={{ fontSize: 16, lineHeight: 1.5 }}>
          Swipe through names from around the world. When you and your partner land on the same one, it blooms into a match.
        </p>
      </div>

      <div className="panel" style={{ padding: 20 }}>
        <div className="seg">
          <button data-on={mode === "signup"} onClick={() => setMode("signup")}>Create account</button>
          <button data-on={mode === "signin"} onClick={() => setMode("signin")}>Sign in</button>
        </div>

        {mode === "signup" && (
          <label className="field">
            <span>Your name</span>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Sam" autoComplete="name" />
          </label>
        )}
        <label className="field">
          <span>Email</span>
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" type="email" autoComplete="email" />
        </label>
        {!DEMO && (
          <label className="field">
            <span>Password</span>
            <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" autoComplete={mode === "signup" ? "new-password" : "current-password"} placeholder="••••••••" />
          </label>
        )}

        {err && <p style={{ color: "var(--coral-deep)", fontSize: 14, margin: "2px 4px 12px", fontWeight: 600 }}>{err}</p>}

        <button className="btn btn-coral" disabled={busy || !email || (mode === "signup" && !name)} onClick={submit}>
          {busy ? "One moment…" : mode === "signup" ? "Create account" : "Sign in"}
        </button>
      </div>

      {DEMO && (
        <p className="muted" style={{ fontSize: 13, textAlign: "center", marginTop: 16, lineHeight: 1.5 }}>
          You're in <strong>Demo Mode</strong> — accounts are saved in this browser only. Create two accounts to play both partners on one device. Add Supabase keys to enable real two-device sync.
        </p>
      )}

      <style>{`
        .seg { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; background: var(--ground-2); padding: 5px; border-radius: 999px; margin-bottom: 18px; }
        .seg button { height: 42px; border-radius: 999px; font-weight: 700; font-size: 14px; color: var(--ink-soft); }
        .seg button[data-on="true"] { background: var(--white); color: var(--ink); box-shadow: var(--shadow-soft); }
      `}</style>
    </div>
  );
}
